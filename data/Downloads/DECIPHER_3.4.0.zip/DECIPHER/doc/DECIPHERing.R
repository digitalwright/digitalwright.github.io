### R code from vignette source 'DECIPHERing.Rnw'

###################################################
### code chunk number 1: DECIPHERing.Rnw:54-56
###################################################
options(continue=" ")
options(width=80)


###################################################
### code chunk number 2: startup
###################################################
library(DECIPHER)


