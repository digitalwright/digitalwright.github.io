#include "_Biostrings_stubs.c"
